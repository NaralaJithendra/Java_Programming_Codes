# Java-problems
<p align="center">
<a href="https://github.com/Srinusivarathri/Java-problems">
  <img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=Srinusivarathri&layout=compact&theme=gotham&hide_border=true&bg_color=00000000&text_color=3498db&layout=compact" />
  <img align="center" src="https://github-readme-stats.vercel.app/api?username=Srinusivarathri&theme=gotham&hide_border=true&bg_color=00000000&text_color=3498db&count_private=true&icon_color=439975" alt="Srinu's github stats"/>
</a></p>
<ul>
<li>
<a href="https://github.com/Srinusivarathri" class="mr-2" data-hovercard-type="user" data-hovercard-url="/users/Srinusivarathri/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self">
        <img src="https://avatars.githubusercontent.com/u/123795650?s=64&amp;v=4" alt="@Srinusivarathri" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
      <span data-view-component="true" class="flex-self-center min-width-0 css-truncate css-truncate-overflow width-fit flex-auto">
        <a href="https://github.com/Srinusivarathri" class="Link--primary no-underline flex-self-center">
          <strong>Srinusivarathri</strong>
          <span class="color-fg-muted">Srinu Sivarathri</span>
        </a>
</span></li>
<li>
<a href="https://github.com/NaralaJithendra" class="mr-2" data-hovercard-type="user" data-hovercard-url="/users/NaralaJithendra/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self">
        <img src="https://avatars.githubusercontent.com/u/93598141?s=64&amp;v=4" alt="@NaralaJithendra" size="32" height="32" width="32" data-view-component="true" class="avatar circle" />
      </a>
      <span data-view-component="true" class="flex-self-center min-width-0 css-truncate css-truncate-overflow width-fit flex-auto">
        <a href="https://github.com/NaralaJithendra" class="Link--primary no-underline flex-self-center">
          <strong>NaralaJithendra</strong>
          <span class="color-fg-muted">Narala Jithendra</span>
        </a>
</span></li>
</ul>
<div class="BorderGrid-row">
              <div class="BorderGrid-cell">
                <h2 class="h4 mb-3">Languages</h2>
<div class="mb-2">
  <span data-view-component="true" class="Progress">
    <span style="background-color:#b07219 !important;;width: 100.0%;" itemprop="keywords" aria-label="Java 100.0" data-view-component="true" class="Progress-item color-bg-success-emphasis"></span>
</span></div>
<ul class="list-style-none">
    <li class="d-inline">
        <a class="d-inline-flex flex-items-center flex-nowrap Link--secondary no-underline text-small mr-3" href="/Srinusivarathri/Java-problems/search?l=java"  data-ga-click="Repository, language stats search click, location:repo overview">
          <svg style="color:#b07219;" aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-dot-fill mr-2">
    <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8z"></path>
</svg>
          <span class="color-fg-default text-bold mr-1">Java</span>
          <span>100.0%</span>
        </a>
    </li>
</ul>
</div>
</div>
<p align="center">
  <i>Let's connect and chat! Open to anything.</i>
  <p align="center">
    <a href="https://github.com/Srinusivarathri">Srinu Sivarathri<img alt=" GitHub" width="22px" src="https://github.com/Srinusivarathri/Srinusivarathri/blob/main/New%20folder/github.svg" /></a>
    </p>
 <p align="center">
 <i>Collaborated With</i>
  <p align="center">
    <a href="https://github.com/NaralaJithendra">Narala Jithendra<img alt=" GitHub" width="22px" src="https://github.com/Srinusivarathri/Srinusivarathri/blob/main/New%20folder/github.svg" /></a>
    </p>
